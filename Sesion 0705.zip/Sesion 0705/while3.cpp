#include <iostream>
using namespace std;
// No es finito
// Se usa cuando no conozco cuantas veces voy a repetir el ciclo
int main()
{
    int op;
    while (op != -1)
    {
        cout << "Dime un numero: ";
        cin >> op;
    }
}
