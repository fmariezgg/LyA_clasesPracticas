#include <iostream>

using namespace std;

int main(int argc, char const *argv[])
{

    int i =0;
    while(i<=9){
        cout << i << endl;
        i++;
    }
    return 0;
}