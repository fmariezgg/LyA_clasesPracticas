#include <iostream>

using namespace std;

int main(int argc, char const *argv[])
{
    while(true){
        cout << "01";
        false;
    }
    return 0;
}